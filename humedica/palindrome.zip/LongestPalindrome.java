package main;

public class LongestPalindrome {

	public static final String DEFAULT_STRING="fourscoreandsevenyearsagoourfaathersbroughtforthonthiscontainentanewnationconceivedinzLibertyanddedicatedtothepropositionthatallmenarecreatedequalNowweareengagedinagreahtcivilwartestingwhetherthatnaptionoranynartionsoconceivedandsodedicatedcanlongendureWeareqmetonagreatbattlefiemldoftzhatwarWehavecometodedicpateaportionofthatfieldasafinalrestingplaceforthosewhoheregavetheirlivesthatthatnationmightliveItisaltogetherfangandproperthatweshoulddothisButinalargersensewecannotdedicatewecannotconsecratewecannothallowthisgroundThebravelmenlivinganddeadwhostruggledherehaveconsecrateditfaraboveourpoorponwertoaddordetractTgheworldadswfilllittlenotlenorlongrememberwhatwesayherebutitcanneverforgetwhattheydidhereItisforusthelivingrathertobededicatedheretotheulnfinishedworkwhichtheywhofoughtherehavethusfarsonoblyadvancedItisratherforustobeherededicatedtothegreattdafskremainingbeforeusthatfromthesehonoreddeadwetakeincreaseddevot iontothatcauseforwhichtheygavethelastpfullmeasureofdevotionthatweherehighlyresolvethatthesedeadshallnothavediedinvainthatthisnationunsderGodshallhaveanewbirthoffreedomandthatgovernmentofthepeoplebythepeopleforthepeopleshallnotperishfromtheearth";
	/**
	 * @param args Either a string you want to be tested, or nothing for a concatenated version of the Gettysburg address.
	 */
	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		
		String candidateString = DEFAULT_STRING;
		if(args.length > 0){
			candidateString = args[0]; 
		}

		System.out.println("Finding longest palindomic substring in string:\n" + candidateString);
		
		boolean found = false;
		for(String maybePalindrome : new AllSubstrings(candidateString)){
			if(isPalindrome(maybePalindrome)){
				System.out.println(maybePalindrome);
				found = true;
				break;
			}
		}
		
		if( ! found ){
			System.out.println("(No palindromes found.)");
		}
		
		long endTime = System.currentTimeMillis();
		System.out.println("Finished in " + ( (endTime - startTime) / 1000) + " seconds.");
		
		System.exit(found ? 0: 1);
	}

	public static boolean isPalindrome(String maybePalindrome){
		if(! endCharsMatch(maybePalindrome)){
			return false;
		}
		
		String reversed = new StringBuilder(maybePalindrome).reverse().toString();
		return reversed.equals(maybePalindrome);
	}
	
	public static boolean endCharsMatch(String maybePalindrome){
		int end = maybePalindrome.length() - 1;
		
	    if(maybePalindrome.charAt(0) == maybePalindrome.charAt(end)){
	    	return true;
	    }
	    
	    return false;
	}
	
	
} // end of main class LongestPalindrome
