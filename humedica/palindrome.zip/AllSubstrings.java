package main;

import java.util.Iterator;

/**
 * An iterable that returns all substrings, in order by decreasing length
 * @author swirepe
 *
 */
public class AllSubstrings implements Iterable<String> {

	protected IteratorChain<String> substringChain;
	
	public AllSubstrings(String fullString){
		this.substringChain = new IteratorChain<String>();
		buildSubstringChain(fullString);
	}


	protected void buildSubstringChain(String fullString){
		// run from biggest to smallest, since we want to find the largest palindromic substring
		for(int substringLength = fullString.length(); substringLength > 0; substringLength--){
			this.substringChain.add(new SubStringIterator(fullString, substringLength));
		}
	}
	
	@Override
	public Iterator<String> iterator() {
		return this.substringChain;
	}

}
