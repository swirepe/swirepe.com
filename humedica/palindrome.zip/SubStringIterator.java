package main;

import java.util.Iterator;


/**
 * An iterator that marches through a string, yielding all substrings of a provided length
 * @author swirepe
 *
 */
public class SubStringIterator implements Iterator<String> {

	protected String fullString;
	protected int substringLength;
	protected int currentIndex = 0;
	
	public SubStringIterator(String fullString, int substringLength){
		if(substringLength > fullString.length()){
			throw new IllegalArgumentException("Substring length cannot be longer than the string length");
		}
		
		if(substringLength < 1){
			throw new IllegalArgumentException("Substring length cannot be less than 1");
		}
		
		
		this.fullString = fullString;
		this.substringLength = substringLength;

	} // end of constructor
	
	
	protected int endIndex(){
		return this.currentIndex + this.substringLength;
	}
	
	@Override
	public boolean hasNext() {
		if(endIndex() < this.fullString.length() ){
			return true;
		}
		
		return false;
	}

	@Override
	public String next() {
		String retString = fullString.substring(this.currentIndex, endIndex());
		this.currentIndex += 1;
		return retString;
	}

	@Override
	public void remove() {
		// do nothing.
	}

} // end of class SubStringIterator
