package main;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Takes a collection of iterators and has them behave like one iterator.
 * (Think of python's itertools.chain)
 * (Apache Commons and Google Guava have java libraries that do this as well)
 * @author swirepe
 *
 * @param <T> The type that the iterators yield
 */
public class IteratorChain<T> implements Iterator<T>{

	protected ArrayList<Iterator<T>> iteratorChain;
	
	public IteratorChain(){
		this.iteratorChain = new ArrayList<Iterator<T>>();
	}
	
	public IteratorChain(ArrayList<Iterator<T>> chain){
		this();
		for(Iterator<T> item: chain){
			this.iteratorChain.add(item);
		}
	}

	public void add(Iterator<T> item){
		this.iteratorChain.add(item);
	}
	
	@Override
	public boolean hasNext() {
		for(Iterator<T> item: this.iteratorChain){
			if(item.hasNext()){
				return true;
			}
		}
		return false;
	}

	
	@Override
	public T next() {
		for(Iterator<T> item: this.iteratorChain){
			if(item.hasNext()){
				return item.next();
			}
		}
		return null;
	}

	
	@Override
	public void remove() {
		// not applicable
	}
	
} // end of class IteratorChain
